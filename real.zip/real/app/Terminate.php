<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Terminate extends Model
{
    //
}
