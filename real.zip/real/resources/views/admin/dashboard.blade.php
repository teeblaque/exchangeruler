
@extends('user.main')
<?php
session_start();
use App\Order;
?>
@section('title')
    <h4>
        <i class="icon-orders"></i>
        Users
    </h4>
@endsection
@section('contents')

    <div class="container-fluid animatedParent animateOnce">

                  
                  <style>
                  .wrap{
                      display: flex;
                      overflow: scroll;
                  }
                    .one{
                        width: 30%;
                        height: 80px;
                        background-color: green;
                        float: left;
                        margin-left: 2%;
                        font-size: 20px;
                        padding-top: 30px;
                        padding-left: 30px;
                    }
                    .hr{
                        border: 1px solid grey;
                    }
             
                     
                  </style>
                    <div class="wrap">
                      <div class="one bg-primary" >
                          <p class="card-text" style="color: white">All orders: {{Order::count()}}</p>
                       </div>
                   
                      
                        <div class="one bg-danger">
                          <p class="card-text" style="color: white">Pending orders: {{Order::where('status','pending')->count()}}</p>
                        </div>
                     
                     
                        <div class="one bg-success">
                          <p class="card-text" style="color: white">Completed Orders: {{Order::where('status','completed')->count()}}</p>
                        </div>
                    
                        <div class="one bg-warning">
                          <p class="card-text" style="color: white">Cancelled orders: {{Order::where('status','cancelled')->count()}}</p>
                        </div>
                      </div>
                      <hr class="hr">
                      <center><i class="fa fa-bar-chart" style='font-size: 18px'></i> <b>Analyctics and Charts</b></center>
                      <hr>
                      <p class="alert alert-primary">Please, click the link below:[visitorCounter] </p>
                      <?php
                      echo $_SESSION['counter'];
                      ?>
                    <hr>
               </div>

    <!-- Edit code ends -->


@endsection
