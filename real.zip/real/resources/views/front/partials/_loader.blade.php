<div id="loader-wrapper" style="position: fixed;">
    <div id="loader">
        <img src="{{ asset('images/logo_1.png') }}" width="70" height="70" alt="" class="load">
    </div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
