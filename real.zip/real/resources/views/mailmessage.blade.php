an order has just been placed.
Order by {{Auth::user()->name}} 
Email: {{Auth::user()->email}}
