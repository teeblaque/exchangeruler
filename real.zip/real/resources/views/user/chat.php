<marquee behaviour="scroll" direction="left">

<h1>Chat room under construction</h1>
</marquee>
<h1>It will  be back soon</h1>