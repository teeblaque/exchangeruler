@extends('user.main')

@section('title')
    <h4>
        <!--<i class="icon-box">-->
        <i class="icon-dashboard" style="font-color:black"></i><font color="black"> Dashboard</font>
    </h4>
@endsection

@section('contents')
    <div class="container-fluid animatedParent animateOnce my-3">
            <div class="animated fadeInUpShort">
                
                    <div id="wrapper">  
                        <div id="user-container"> 
                        <form>
                           <textarea placeholder="Message area" class="form-control" rows="10" readonly>
                            </textarea><br>
                            </form>
                            <label for="user">What's your name?</label>
                            <input type="text" id="user" name="user" class="form-control">
                            <button type="button" id="join-chat" class="form-control btn btn-success" >Join Chat</button>
                        </div>
                
                        <div id="main-container" class="hidden">        
                            <button type="button" id="leave-room" class="form-control btn btn-danger">Leave</button>
                            <div id="messages">
                
                            </div>
                
                            <div id="msg-container">
                                <input type="text" id="msg" name="msg">
                                <button type="button" id="send-msg" class="form-control btn btn-primary">Send</button>
                            </div>
                        </div>
                
                    </div>
             
                
              </div>
            </div>
@endsection