<style>
    .f{
        display: flex;
    }
    
</style>

<div class="page has-sidebar-left height-full">
          <header style="background-color: white">
            <div class="container-fluid text-white">
              <div class="row p-t-b-10 ">
                <div class="col">
                    @yield('title')
                </div>
              </div>
            </div>
          </header>
          <div class="alert alert-warning" style="background-color: orange; color: white">
            <p class="ssf" style="color: white"> <b>Disclaimer!</b> We do not trade on instagram, twitter or any social media platform. The only whatsapp we trade on is <b>+2348180682860</b> for very bulky transactions. <b>BEWARE OF SCAMMERS!</b></p>
          </div>
          
          <div class="f">
          <div class="alert alert-danger" style="font-size: 15px">
           <b>Note!</b> Please note that we are not responsible for <b>cryptocurrency charges</b> on our website
          </div>
          <div class="alert alert-danger" style="font-size: 15px">
             <b>Attention!</b> Kindly check the <b>Wallet address</b> before sending
          </div>
        </div>