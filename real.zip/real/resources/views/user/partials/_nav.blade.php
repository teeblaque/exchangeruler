<div class="has-sidebar-left sti">
        <div class="pos-f-t">
          <div class="collapse" id="navbarToggleExternalContent">
            <div class="bg-dark pt-2 pb-2 pl-4 pr-2">
              <div class="search-bar">
                <input class="transparent s-24 text-white b-0 font-weight-lighter w-128 height-50" type="text" placeholder="start typing...">
              </div>
              <a href="#" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation" class="paper-nav-toggle paper-nav-white active "><i></i></a>
            </div>
          </div>
        </div>
        <div class="sticky">
          <div class="navbar navbar-expand navbar-dark d-flex justify-content-between bd-navbar green accent-3">
            <div class="relative">
              <a href="#" data-toggle="push-menu" class="paper-nav-toggle pp-nav-toggle">
                <i></i>
              </a>
            </div>

            <div class="navbar-custom-menu">
              <ul class="nav navbar-nav">
                <li>
                  <a class="nav-link ml-2" data-toggle="control-sidebar">
                  </a>
                </li>

                <li class="dropdown custom-dropdown user user-menu ">
                  <div class="avatar">
                    <span class="avatar-letter avatar-letter-t circle green"></span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
